![Build Status](https://github.com/sanyarnd/java-course-2023/actions/workflows/build.yml/badge.svg)

Домашние задания курса https://fintech.tinkoff.ru/academy/java

Студент: `ФИО`
